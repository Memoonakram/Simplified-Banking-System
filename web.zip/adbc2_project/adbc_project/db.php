<?php
// Database configuration
$servername = "localhost";
$username = "root";       // MySQL default username for XAMPP
$password = "";           // MySQL default password for XAMPP is empty
$dbname = "adbc_project";         // Database name we created

// Create a new MySQLi connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
